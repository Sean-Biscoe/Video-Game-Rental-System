Hi Firat,

I have created my game so that it follows the criteria required up to the 
inventory pruning where I used both the rental file and the game feedback
file to output the best rated games and also the most popular and least popular.

I have implemented the customers so that premium customers can only rent out 7
games thorughout their subscription time, and basic can only rent out 2.

I have done thoroughly detailed docstrings and tests for functions.
I have a functioning gui that is clear and easy to use.

When renting, you may use the following customer IDs and more:
GOBL, SPUD, BILL, wbkv, QHGI, rasp, base, abcd.

The customers that have rented out the maximum limit are and more:
coai, efgh

You can use the game search module in the gui menu to find available games.
In the function manager, the add feedback function worked but the load feedback
did not work on my laptop so I manually coded it in myself.

The only error you may encounter is the magic black number error which is 
caused by the subsciption manager file when you run the pyc file on the 
haslegrave windows computers. This is not caused by any of my files.